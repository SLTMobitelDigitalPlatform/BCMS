import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Sidebar from './components/SideBar';
import Header from './components/Header';
import BCPlans from './pages/BCPlans';
import BCPForm from './pages/BCPForm';
import CBFunctions from './pages/CBFunctions';
import DocumentControl from './pages/DocumentControl';
import ExternalDependencies from './pages/ExternalDependencies';
import GrabList from './pages/GrabList';
import InternalDependenciesDown from './pages/InternalDependenciesDown';
import InternalDependenciesUP from './pages/InternalDependenciesUP';
import LRCRequirements from './pages/LRCRequirements';
import MPROpt2 from './pages/MPROpt2';
import MPRWelikada from './pages/MPRWelikada';
import PIPreparation from './pages/PIPreparation';
import RecoveryResumption from './pages/RecoveryResumption';
import RecoveryStrategy from './pages/RecoveryStrategy';
import ResourceRequired from './pages/ResourceRequired';
import VitalRecords from './pages/VitalRecords';
import WorkAreaRecovery from './pages/WorkAreaRecovery';
import './App.css';

const App = () => {
  return (

    
    <Router>
      <div className="App">
        <Header />
        <Sidebar />
        <div className="content">
          <Routes>
            {/* Define routes for each page */}
            <Route path="/" element={<BCPlans />} /> {/* Default landing page */}
            <Route path="/bcpform" element={<BCPForm />} />
            <Route path="/cbfunctions" element={<CBFunctions />} />
            <Route path="/documentcontrol" element={<DocumentControl />} />
            <Route path="/externaldependencies" element={<ExternalDependencies />} />
            <Route path="/grablist" element={<GrabList />} />
            <Route path="/internaldependenciesdown" element={<InternalDependenciesDown />} />
            <Route path="/internaldependenciesup" element={<InternalDependenciesUP />} />
            <Route path="/lrcrequirements" element={<LRCRequirements />} />
            <Route path="/mpropt2" element={<MPROpt2 />} />
            <Route path="/mprwelikada" element={<MPRWelikada />} />
            <Route path="/pipreparation" element={<PIPreparation />} />
            <Route path="/recoveryresumption" element={<RecoveryResumption />} />
            <Route path="/recoverystrategy" element={<RecoveryStrategy />} />
            <Route path="/resourcerequired" element={<ResourceRequired />} />
            <Route path="/vitalrecords" element={<VitalRecords />} />
            <Route path="/workarearecovery" element={<WorkAreaRecovery />} />
            
            {/* Wildcard route for 404 Page Not Found */}
            <Route path="*" element={<div>404 Page Not Found</div>} />
          </Routes>
        </div>
      </div>
    </Router>
  );

};

export default App;
