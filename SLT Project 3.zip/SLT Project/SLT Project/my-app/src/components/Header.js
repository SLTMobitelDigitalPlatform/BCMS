import React from 'react';
import '../css/Header.css';
import Logo from '../assets/logo.png';

const Header = () => {
  return (
    <div className="header">
      <div className="logo-search">
        <div className="logo">
          <img 
            src={Logo} 
            alt="logo" 
            className="logo-img"
          />
        </div>
        <div className="search-container">
          <i className="fas fa-search search-icon"></i>
          <input className="search-bar" type="text" placeholder="Search" />
        </div>
      </div>
      <div className="icons">
        <i className="fas fa-home"></i>
        <i className="fas fa-file-alt"></i>
        <i className="fas fa-users"></i>
        <i className="fas fa-bell"></i>
        <i className="fas fa-user-circle"></i>
      </div>
    </div>
  );
};

export default Header;
