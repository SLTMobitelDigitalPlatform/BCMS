import React, { useState } from 'react';
import '../css/SideBar.css';
import dropdownArrow from '../assets/dropdown.png';

const Sidebar = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <div className="sidebar">
      <h1 className="sidebar-title">BCMS</h1>
      <h2 className="subtitlee">Dashboard</h2>
      <ul className="sidebar-menu">
        <li><a href="#employee">Employee</a></li>
        <li className="dropdown-toggle" onClick={toggleDropdown}>
          <a href="#documents">Documents</a>
          <img 
            src={dropdownArrow}
            alt="arrow"
            className="dropdown-arrow"
          />
        </li>
        {isDropdownOpen && (
          <ul className="dropdown-menu">
            <li><a href="#document1">Document 1</a></li>
            <li><a href="#document2">Document 2</a></li>
            <li><a href="#document3">Document 3</a></li>
            <li><a href="#document4">Document 4</a></li>
          </ul>
        )}
        <li><a href="#meetings">Meetings</a></li>
        <li><a href="#calendar">Calendar</a></li>
        <li><a href="#risk-management">Risk Management</a></li>
        <li><a href="#roles-responsibilities">Roles & Responsibilities</a></li>
      </ul>
      <button className="logout-btn">Log Out</button>
    </div>
  );
};

export default Sidebar;
