import React from 'react';
import { Link, Outlet } from 'react-router-dom';
import '../css/Layout.css';

const Layout = () => {
  return (
    <div className="middlesection">
      <div className="nav-buttons">
        <Link to="/bcpform" className="nav-button">BCP Form</Link>
        <Link to="/cbfunctions" className="nav-button">CB Functions</Link>
        <Link to="/documentcontrol" className="nav-button">Document Control</Link>
        <Link to="/grablist" className="nav-button">Grab List</Link>
        <Link to="/internaldependenciesdown" className="nav-button">Internal Dependencies Down</Link>
        <Link to="/lrcrequirements" className="nav-button">Legal Regulatory & Contractual Requirements</Link>
        <Link to="/mpropt2" className="nav-button">MPR Opt2</Link>
        <Link to="/mprwelikada" className="nav-button">MPR Welikada</Link>
        <Link to="/pipreparation" className="nav-button">Pre-Incident Preparation</Link>
        <Link to="/recoveryresumption" className="nav-button">Recovery Resumption</Link>
        <Link to="/recoverystrategy" className="nav-button">Recovery Strategy</Link>
        <Link to="/resourcerequired" className="nav-button">Resource Required</Link>
        <Link to="/vitalrecords" className="nav-button">Vital Records</Link>
        <Link to="/workarearecovery" className="nav-button">Work Area Recovery</Link>
      </div>
    </div>
  );
};

export default Layout;
