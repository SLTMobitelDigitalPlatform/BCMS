import React from 'react';

const InternalDependenciesUP = () => {
  return (
    <div>
      <h1>This is Page 1</h1>
    </div>
  );
};

export default InternalDependenciesUP;