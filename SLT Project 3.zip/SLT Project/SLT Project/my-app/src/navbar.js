export default function Navbar(){
    return (
        <nav className="nav">
        <a href="/" className="site-title">
          site name
        </a>
       <ul>
        <li><a href="/about">About</a></li>
        <li><a href="/contact">Contact</a></li>
        <li><a href="/user">User</a></li>

    
       </ul>
       </nav>
   )         
}